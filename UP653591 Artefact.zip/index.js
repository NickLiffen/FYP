//Require Babel for my ES6 to ES5 translation
require("babel-core/register");
//Require the Server File for Babel to use, this is the first file called.
require("./server.js");
